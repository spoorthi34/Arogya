from django.urls import path
from django.http import HttpResponse

def test(request):
    return HttpResponse("Doctors API working!")

urlpatterns = [
    path('', test),
]
