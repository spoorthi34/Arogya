

from django.urls import path
from . import views

urlpatterns = [
    # Example API endpoint
    path('patients/', views.PatientList.as_view(), name='patient-list'),
]
