from django.contrib import admin
from .models import Patient  # import your model

admin.site.register(Patient)  # register it
