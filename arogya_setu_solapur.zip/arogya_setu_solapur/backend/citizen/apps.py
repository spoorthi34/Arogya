from django.apps import AppConfig


class CitizenConfig(AppConfig):
    name = "citizen"
